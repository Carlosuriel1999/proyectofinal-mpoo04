//
//  SecondMaterias.swift
//  FiCognita
//
//  Created by Macbook on 5/8/19.
//  Copyright © 2019 Macbook. All rights reserved.
//
import UIKit

class SecondMaterias: UIViewController {
    
    
var dato: String = ""


override func viewDidLoad() {
    
    
    super.viewDidLoad()

//  nombre.text = dat0

    // dismiss(animated: true, completion: nil)
    
}
}
