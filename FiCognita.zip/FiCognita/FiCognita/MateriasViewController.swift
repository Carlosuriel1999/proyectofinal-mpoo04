//
//  MateriasViewController.swift
//  FiCognita
//
//  Created by Macbook on 5/8/19.
//  Copyright © 2019 Macbook. All rights reserved.
//


// tableview controller para vistas completas y sin datos activos( como botones que hagan algo)
//protocolos nos da el diseño del metodo
// la tabla necesita 2 protocolos Uitableviewdatasource y  UITableViewDelegate
import UIKit

class MateriasViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    var Materia: [String] = ["Algebra", "Calculo Diferencial", "Quimica", "Vectorial", "Termodinamica"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //funciuones de protocolo UITableViewDataSource
    
    //regresa un entero, numberOfRowsInSection es numero de renglones, este metodo pinta lod renglones en la secion
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Materia.count  // numero de renglones a regresar
    }
    
    //indexPath tiene info de los renglones, cual fue tocadfo etc.
    // dame una celda para el renglon en => la funcion de abajo
    // dame una celda reusable dequeueReusableCell
    
    //delegar tableview a asu controlador en main dando click a table view y galar a la vista y darle dataSource => da los datos
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.backgroundColor = .magenta
        cell.textLabel!.text = Materia[indexPath.row]
        
        return cell   // se va a llamar 4 veces porq pedi 4 celdas
    }
    
    // se selecciono el renglon en
    
    // delegar => ve la seciones disponibles
    
    // alerts
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let optionMenu = UIAlertController(title: "Bienvenido", message: "deseas seleccionar esta materia?", preferredStyle: .alert)   // puede ser actionsheet o alert
        
        let cancelAction = UIAlertAction(title: "cancelar", style: .cancel, handler: nil)
        
        // un closure implementadfo empieza con in
        let okAction = UIAlertAction(title: "ok", style: .default) { (UIAlertAction) -> Void in
            let cell = tableView.cellForRow(at: indexPath)
            
            // si la celda es igua a
            if  cell?.accessoryType.rawValue == 0{
                cell?.accessoryType = .checkmark
            }else{
                cell?.accessoryType = .none
            }
            
            // ejecuta el segue con identificador y te lo mando yo
            self.performSegue(withIdentifier: "vista2materia", sender: self)
        }
        
        optionMenu.addAction(okAction)
        optionMenu.addAction(cancelAction)
        
        // los presento cuando de un click en eln dato
        present(optionMenu, animated: true, completion: nil)
        
        // print(indexPath.row)
    }
    // funcion preparame mandamos el dato de la celda
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "vista2materia"){
            let indexPath = tabla.indexPathForSelectedRow
            let vista2 = segue.destination as? MateriasSecond
            vista2?.dato = Materia[(indexPath?.row)!]
        }
        
        
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        print(identifier)
        return false
    }
    
}


