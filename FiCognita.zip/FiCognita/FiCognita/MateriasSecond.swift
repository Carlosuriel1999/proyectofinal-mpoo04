//
//  MateriasSecond.swift
//  FiCognita
//
//  Created by Macbook on 5/8/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class MateriasSecond: UIViewController  {
    
    
    @IBOutlet weak var nombre: UILabel!
    
    var dato: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        nombre.text = dato
        
        
    }
    
    @IBAction func cerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}
